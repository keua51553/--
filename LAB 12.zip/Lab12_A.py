f = open('input.txt','r')
c = 0
while True:
    lines = f.readline()
    if lines == '':
        break
    elif c == 0:
        k = open('output.txt','w')
        k.write(lines.capitalize())
        k.close()
        c+=1
    else:
        k = open('output.txt','a')
        k.write(lines.capitalize())
        k.close()


