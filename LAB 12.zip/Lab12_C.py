try:
    i = input('Enter a number: ')
    i = float(i)
    k = input('Enter another number: ')
    k =float(k)
    print(str(i+k))
except:
    print('ERROR: Invalid input')

