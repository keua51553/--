import os.path
i = input()
if os.path.isfile(i):
    f = open(i,'r')
    print(f.read())
else:
    print('ERROR: File not found')
